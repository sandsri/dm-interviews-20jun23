package com.example.demo.service;

import com.example.demo.model.Inventory;
import java.util.List;

public interface InventoryService {
    List<Inventory> getAllInventory();
    Inventory getInventoryById(Long id);
    Inventory saveOrUpdate(Inventory inventory);
    void deleteInventory(Long id);
}

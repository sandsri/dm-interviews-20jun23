package com.example.externalApiInvokeDemo.service;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class UniversityService {
    private final RestTemplate restTemplate = new RestTemplate();

    public String searchUniversityByName(String name) {
        String url = "http://universities.hipolabs.com/search?name=" + name;
        try {
            ResponseEntity<String> response = restTemplate.getForEntity(url, String.class);
            return response.getBody();
        } catch (Exception e) {
            throw new RuntimeException("Failed to fetch data from external API", e);
        }
    }
}
